
#define B80M 9
#define B60_40M 8
#define B30_20M 7
#define B17_15M 6
#define B12_10M 4
#define RX_HI 5
#define TX_HI 10
#define DC_PTT 13
#define EX_PTT A3
#define EX_GP A2
#define Y_LED 12
#define R_LED 11

#define AT10DB 2
#define AT20DB 3
#define TS_PIN A0

